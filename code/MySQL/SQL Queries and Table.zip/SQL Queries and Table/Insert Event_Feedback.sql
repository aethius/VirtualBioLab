SELECT * FROM Feedback;

INSERT INTO Feedback (Event_Code, Event_Feedback)
VALUES (12346, 'Wrong number of phases, try again!');

SELECT * FROM Feedback;