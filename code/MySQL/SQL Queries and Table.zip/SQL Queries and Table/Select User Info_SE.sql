SELECT * FROM StudentList
WHERE ID = 123456789;

SELECT * FROM ProfessorList
WHERE Last_Name = ;