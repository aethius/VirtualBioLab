SELECT * FROM Feedback
WHERE Event_Code = 12345;

SELECT * FROM Feedback;