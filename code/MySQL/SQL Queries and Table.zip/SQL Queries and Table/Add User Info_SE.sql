SELECT * FROM StudentList;

INSERT INTO StudentList (ID, First_Name, Last_Name, Email, UserName, Lab_Section, Professor_Name) 
VALUES (123456793, 'Evan', 'Chipps', 'echips@rutgers.edu', 'EChipps', 148, 'James Morgan');

SELECT * FROM StudentList;

SELECT * FROM ProfessorList;

INSERT INTO ProfessorList (First_Name, Last_Name, UserName, Email, Section )
VALUES ('James', 'Morgan', 'JMorgan', 'jmorgan@rutgers.edu', 148  );

SELECT * FROM ProfessorList;