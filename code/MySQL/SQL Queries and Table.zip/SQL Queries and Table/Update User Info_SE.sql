SELECT * FROM StudentList;

Update StudentList
SET ID = 123456789
WHERE ID = 1;

SELECT * FROM StudentList;

SELECT * FROM ProfessorList;

Update ProfessorList
SET Section = 
WHERE SECTION = ;

SELECT * FROM ProfessorList;